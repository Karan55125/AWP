<?php 
$con=new mysqli("localhost","root","","master");
if(!$con)
{
	die("Connection failed".mysqli_connect_error());
	
	
}
$str="select * from customer";
$result=mysqli_query($con,$str);


while($row=mysqli_fetch_array($result))
{ 

	echo  $row[0].$row[1].$row[2]."<br>";
	
}
mysqli_close($con);
?>