<?php 
$data=$_REQUEST['key'];
$URLData=explode(",",$data);

//Creating Database connection
$con= new mysqli("localhost","root","","master");
if(!$con)
{
		die("Connection Failed".mysqli_connect_error());
}
$sql="insert into employee(empid,name,Department)values('$URLData[0]','$URLData[1]','$URLData[2]')";
if(mysqli_query($con,$sql))
{
	echo "Record is inserted";
}
?>