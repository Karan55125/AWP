<?php 
$data=$_REQUEST['datavalue'];
$a=array('Pune','Mumbai','Kolhapur','Shirpur');
$b=array('Gorakphur','Kanpur','Lucknow');
$c=array('Patna');
if($data=="Maharashtra")
{
	foreach($a as $aone)
	{
		echo"<option>$aone</option>";
	}
}
if($data=="UP")
{
	foreach($b as $aone)
	{
		echo"<option>$aone</option>";
	}
}
if($data=="Bihar")
{
	foreach($c as $aone)
	{
		echo"<option>$aone</option>";
	}
}
?>
