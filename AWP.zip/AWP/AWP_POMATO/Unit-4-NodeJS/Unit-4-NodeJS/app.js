var mylog=require('./log.js');
mylog.info("Node JS Started");